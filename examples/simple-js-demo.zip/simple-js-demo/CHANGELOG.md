# simple-js-demo

## 1.0.11

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.3.0

## 1.0.10

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.2.0

## 1.0.9

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.1.1

## 1.0.8

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.1.0

## 1.0.7

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.8

## 1.0.6

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.7

## 1.0.5

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.6

## 1.0.4

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.5

## 1.0.3

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.4

## 1.0.2

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.3

## 1.0.1

### Patch Changes

- Updated dependencies []:
  - @mindfiredigital/pivothead@1.0.2
